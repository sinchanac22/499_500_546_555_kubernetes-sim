# Kubernetes-like Cluster Simulation Framework - Architecture

This document outlines the architecture of the Kubernetes-like Cluster Simulation Framework.

## System Components

### 1. API Server (Central Control Unit)

The API Server is the central control unit of the cluster. It exposes a RESTful API for client interactions and manages the overall cluster operation. It consists of three key components:

#### 1.1 Node Manager

The Node Manager is responsible for:
- Tracking registered nodes and their statuses
- Maintaining information about node resources (CPU cores)
- Adding and removing nodes from the cluster
- Launching Docker containers to simulate physical nodes

#### 1.2 Pod Scheduler

The Pod Scheduler is responsible for:
- Assigning pods to available nodes based on scheduling policies
- Ensuring pods are placed on nodes with sufficient resources
- Implementing different scheduling algorithms (First-Fit, Best-Fit, Worst-Fit)

#### 1.3 Health Monitor

The Health Monitor is responsible for:
- Receiving health signals from nodes
- Detecting node failures through missed heartbeats
- Initiating recovery actions for failed nodes
- Rescheduling pods from failed nodes to healthy ones

### 2. Nodes

Nodes are computing units that host pods. In this simulation:
- Each node is simulated as a Docker container
- Nodes maintain an array of pod IDs they host
- Nodes periodically send heartbeat signals to the API server
- Each node has a specific CPU capacity

### 3. Pods

Pods are the smallest deployable units in the system:
- Pods require specific CPU resources
- Pods are simulated as entries in the node's pod ID array
- Pods are scheduled on nodes with sufficient resources

## Communication Flow

\`\`\`
+----------------+      REST API      +----------------+
|                |<------------------>|                |
|  Client (UI)   |                    |   API Server   |
|                |                    |                |
+----------------+                    +----------------+
                                           ^   ^
                                           |   |
                                 Heartbeats |   | Commands
                                           |   |
                                           v   v
                      +------------+    +------------+    +------------+
                      |            |    |            |    |            |
                      |   Node 1   |    |   Node 2   |    |   Node N   |
                      |            |    |            |    |            |
                      +------------+    +------------+    +------------+
\`\`\`

## Process Flows

### Node Addition Process

1. User specifies CPU cores for a new node
2. API Server launches a Docker container to simulate the node
3. Node container starts and registers with the API Server
4. Node begins sending heartbeat signals
5. API Server confirms successful node addition

### Pod Launch Process

1. User requests to launch a pod with specific CPU requirements
2. API Server validates resource availability
3. Pod Scheduler selects an appropriate node based on scheduling policy
4. Selected node's resources are updated
5. Pod ID is added to the node's pod array
6. API Server confirms successful pod deployment

### Health Monitoring Process

1. Nodes send regular heartbeat signals to the API Server
2. Health Monitor analyzes heartbeat data and updates node statuses
3. If a node fails to send heartbeats, it's marked as unhealthy
4. For confirmed node failures, pods are rescheduled to healthy nodes
5. System updates its status information

## Scheduling Algorithms

The system implements multiple scheduling algorithms:

1. **First-Fit**: Assigns pods to the first node with sufficient resources
2. **Best-Fit**: Assigns pods to the node that will have the least remaining resources after allocation
3. **Worst-Fit**: Assigns pods to the node with the most available resources
4. **Round-Robin**: Distributes pods evenly across all nodes with sufficient resources

## Fault Tolerance

The system implements fault tolerance through:

1. Regular heartbeat monitoring
2. Detection of failed nodes
3. Automatic pod rescheduling from failed nodes to healthy ones
4. Resource reallocation to maintain service availability
