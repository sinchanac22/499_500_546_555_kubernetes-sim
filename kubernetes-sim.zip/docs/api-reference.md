# API Reference

This document provides a reference for the API endpoints exposed by the Kubernetes-like Cluster Simulation Framework.

## Base URL

All API endpoints are relative to the base URL:

\`\`\`
http://localhost:3001/api
\`\`\`

## Node Operations

### List Nodes

Retrieves a list of all nodes in the cluster.

- **URL**: `/nodes`
- **Method**: `GET`
- **Response**:
  \`\`\`json
  {
    "success": true,
    "data": [
      {
        "id": "node-uuid",
        "totalCpu": 4,
        "usedCpu": 2,
        "status": "healthy",
        "lastHeartbeat": "2025-04-09T12:34:56.789Z",
        "pods": [
          {
            "id": "pod-1",
            "cpuRequest": 1,
            "status": "running",
            "createdAt": "2025-04-09T12:30:00.000Z"
          },
          {
            "id": "pod-2",
            "cpuRequest": 1,
            "status": "running",
            "createdAt": "2025-04-09T12:32:00.000Z"
          }
        ],
        "containerId": "docker-container-id"
      }
    ]
  }
  \`\`\`

### Add Node

Adds a new node to the cluster.

- **URL**: `/nodes`
- **Method**: `POST`
- **Request Body**:
  \`\`\`json
  {
    "cpuCores": 4
  }
  \`\`\`
- **Response**:
  \`\`\`json
  {
    "success": true,
    "data": {
      "id": "node-uuid",
      "totalCpu": 4,
      "usedCpu": 0,
      "status": "healthy",
      "lastHeartbeat": "2025-04-09T12:34:56.789Z",
      "pods": [],
      "containerId": "docker-container-id"
    }
  }
  \`\`\`

### Get Node Details

Retrieves details for a specific node.

- **URL**: `/nodes/:id`
- **Method**: `GET`
- **Response**:
  \`\`\`json
  {
    "success": true,
    "data": {
      "id": "node-uuid",
      "totalCpu": 4,
      "usedCpu": 2,
      "status": "healthy",
      "lastHeartbeat": "2025-04-09T12:34:56.789Z",
      "pods": [
        {
          "id": "pod-1",
          "cpuRequest": 1,
          "status": "running",
          "createdAt": "2025-04-09T12:30:00.000Z"
        },
        {
          "id": "pod-2",
          "cpuRequest": 1,
          "status": "running",
          "createdAt": "2025-04-09T12:32:00.000Z"
        }
      ],
      "containerId": "docker-container-id"
    }
  }
  \`\`\`

## Pod Operations

### Launch Pod

Launches a new pod with specified CPU requirements.

- **URL**: `/pods`
- **Method**: `POST`
- **Request Body**:
  \`\`\`json
  {
    "cpuRequest": 2
  }
  \`\`\`
- **Response**:
  \`\`\`json
  {
    "success": true,
    "data": {
      "id": "pod-3",
      "cpuRequest": 2,
      "status": "running",
      "createdAt": "2025-04-09T12:36:00.000Z",
      "nodeId": "node-uuid"
    }
  }
  \`\`\`

### List Pods

Retrieves a list of all pods in the cluster.

- **URL**: `/pods`
- **Method**: `GET`
- **Response**:
  \`\`\`json
  {
    "success": true,
    "data": [
      {
        "id": "pod-1",
        "cpuRequest": 1,
        "status": "running",
        "createdAt": "2025-04-09T12:30:00.000Z",
        "nodeId": "node-uuid-1"
      },
      {
        "id": "pod-2",
        "cpuRequest": 1,
        "status": "running",
        "createdAt": "2025-04-09T12:32:00.000Z",
        "nodeId": "node-uuid-1"
      },
      {
        "id": "pod-3",
        "cpuRequest": 2,
        "status": "running",
        "createdAt": "2025-04-09T12:36:00.000Z",
        "nodeId": "node-uuid-2"
      }
    ]
  }
  \`\`\`

## Health Monitoring

### Send Heartbeat

Sends a heartbeat signal from a node to the API server.

- **URL**: `/heartbeat`
- **Method**: `POST`
- **Request Body**:
  \`\`\`json
  {
    "nodeId": "node-uuid",
    "status": "healthy"
  }
  \`\`\`
- **Response**:
  \`\`\`json
  {
    "success": true
  }
  \`\`\`

## Error Responses

All API endpoints return a standard error format:

\`\`\`json
{
  "success": false,
  "error": "Error message describing what went wrong"
}
\`\`\`

Common HTTP status codes:
- `400 Bad Request`: Invalid request parameters
- `404 Not Found`: Resource not found
- `500 Internal Server Error`: Server-side error
