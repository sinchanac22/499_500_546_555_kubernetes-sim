import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

import type { Node } from "./types"

// Calculate total cluster CPU capacity
export function calculateTotalCpu(nodes: Node[]): number {
  return nodes.reduce((total, node) => total + node.totalCpu, 0)
}

// Calculate total used CPU across the cluster
export function calculateUsedCpu(nodes: Node[]): number {
  return nodes.reduce((total, node) => total + node.usedCpu, 0)
}

// Calculate cluster CPU utilization percentage
export function calculateCpuUtilization(nodes: Node[]): number {
  const totalCpu = calculateTotalCpu(nodes)
  if (totalCpu === 0) return 0

  const usedCpu = calculateUsedCpu(nodes)
  return (usedCpu / totalCpu) * 100
}

// Count healthy nodes
export function countHealthyNodes(nodes: Node[]): number {
  return nodes.filter((node) => node.status === "healthy").length
}

// Count total pods in the cluster
export function countTotalPods(nodes: Node[]): number {
  return nodes.reduce((total, node) => total + node.pods.length, 0)
}

// Format date for display
export function formatDate(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleString()
}

// Generate a short ID from a longer one
export function shortId(id: string): string {
  return id.substring(0, 8)
}

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
