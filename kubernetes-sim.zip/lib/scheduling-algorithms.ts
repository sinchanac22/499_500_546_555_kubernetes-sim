import type { Node } from "./types"

// First-Fit scheduling algorithm
export function firstFitScheduling(nodes: Node[], cpuRequest: number): Node | null {
  // Find first node with enough CPU
  for (const node of nodes) {
    if (node.status === "healthy" && node.totalCpu - node.usedCpu >= cpuRequest) {
      return node
    }
  }

  return null
}

// Best-Fit scheduling algorithm
export function bestFitScheduling(nodes: Node[], cpuRequest: number): Node | null {
  let bestFitNode: Node | null = null
  let minRemainingCpu = Number.POSITIVE_INFINITY

  // Find node with minimum remaining CPU after allocation
  for (const node of nodes) {
    if (node.status === "healthy") {
      const remainingCpu = node.totalCpu - node.usedCpu

      if (remainingCpu >= cpuRequest && remainingCpu < minRemainingCpu) {
        minRemainingCpu = remainingCpu
        bestFitNode = node
      }
    }
  }

  return bestFitNode
}

// Worst-Fit scheduling algorithm
export function worstFitScheduling(nodes: Node[], cpuRequest: number): Node | null {
  let worstFitNode: Node | null = null
  let maxRemainingCpu = -1

  // Find node with maximum remaining CPU after allocation
  for (const node of nodes) {
    if (node.status === "healthy") {
      const remainingCpu = node.totalCpu - node.usedCpu

      if (remainingCpu >= cpuRequest && remainingCpu > maxRemainingCpu) {
        maxRemainingCpu = remainingCpu
        worstFitNode = node
      }
    }
  }

  return worstFitNode
}

// Round-Robin scheduling algorithm
export function roundRobinScheduling(
  nodes: Node[],
  cpuRequest: number,
  lastNodeIndex: number,
): { node: Node | null; nextIndex: number } {
  if (nodes.length === 0) {
    return { node: null, nextIndex: 0 }
  }

  let currentIndex = lastNodeIndex
  let count = 0

  // Try to find a suitable node starting from the last used index
  while (count < nodes.length) {
    currentIndex = (currentIndex + 1) % nodes.length
    const node = nodes[currentIndex]

    if (node.status === "healthy" && node.totalCpu - node.usedCpu >= cpuRequest) {
      return { node, nextIndex: currentIndex }
    }

    count++
  }

  return { node: null, nextIndex: currentIndex }
}
