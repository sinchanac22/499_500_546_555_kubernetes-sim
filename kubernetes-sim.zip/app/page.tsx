import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Server, Box, Activity } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="px-4 lg:px-6 h-14 flex items-center">
        <Link className="flex items-center justify-center" href="#">
          <Server className="h-6 w-6 mr-2" />
          <span className="font-bold">K8s Simulator</span>
        </Link>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            About
          </Link>
          <Link className="text-sm font-medium hover:underline underline-offset-4" href="#">
            Documentation
          </Link>
          <Link
            className="text-sm font-medium hover:underline underline-offset-4"
            href="https://github.com/your-username/kubernetes-sim"
          >
            GitHub
          </Link>
        </nav>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 xl:py-48">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12 xl:grid-cols-[1fr_600px]">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                    Kubernetes-like Cluster Simulator
                  </h1>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    A lightweight simulation framework that mimics core Kubernetes cluster management functionalities.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/dashboard">
                    <Button size="lg">
                      Get Started <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="https://github.com/your-username/kubernetes-sim">
                    <Button variant="outline" size="lg">
                      View on GitHub
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <div className="grid grid-cols-2 gap-4 md:grid-cols-2">
                  <div className="flex flex-col items-center justify-center space-y-2 border rounded-lg p-4">
                    <div className="p-2 bg-primary/10 rounded-full">
                      <Server className="h-6 w-6" />
                    </div>
                    <h3 className="text-xl font-bold">Node Management</h3>
                    <p className="text-sm text-center text-muted-foreground">
                      Add and monitor nodes with specified CPU resources
                    </p>
                  </div>
                  <div className="flex flex-col items-center justify-center space-y-2 border rounded-lg p-4">
                    <div className="p-2 bg-primary/10 rounded-full">
                      <Box className="h-6 w-6" />
                    </div>
                    <h3 className="text-xl font-bold">Pod Scheduling</h3>
                    <p className="text-sm text-center text-muted-foreground">
                      Schedule pods based on resource requirements
                    </p>
                  </div>
                  <div className="flex flex-col items-center justify-center space-y-2 border rounded-lg p-4">
                    <div className="p-2 bg-primary/10 rounded-full">
                      <Activity className="h-6 w-6" />
                    </div>
                    <h3 className="text-xl font-bold">Health Monitoring</h3>
                    <p className="text-sm text-center text-muted-foreground">
                      Track node health with heartbeat mechanism
                    </p>
                  </div>
                  <div className="flex flex-col items-center justify-center space-y-2 border rounded-lg p-4">
                    <div className="p-2 bg-primary/10 rounded-full">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-6 w-6"
                      >
                        <path d="M12 13V2l8 4-8 4" />
                        <path d="M20.55 10.23A9 9 0 1 1 8 4.94" />
                        <path d="M8 10a5 5 0 1 0 8.9 2.02" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold">Fault Tolerance</h3>
                    <p className="text-sm text-center text-muted-foreground">
                      Automatic pod rescheduling on node failures
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t">
        <p className="text-xs text-muted-foreground">© 2025 Kubernetes-like Cluster Simulator. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Terms of Service
          </Link>
          <Link className="text-xs hover:underline underline-offset-4" href="#">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}
