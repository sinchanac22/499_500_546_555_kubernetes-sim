"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, CheckCircle, Server, Box, RefreshCw, Activity } from "lucide-react"
import { createNode, launchPod, listNodes } from "@/lib/api"
import type { Node } from "@/lib/types"
import { Progress } from "@/components/ui/progress"

export default function Dashboard() {
  const [nodes, setNodes] = useState<Node[]>([])
  const [cpuCores, setCpuCores] = useState<number>(2)
  const [podCpuReq, setPodCpuReq] = useState<number>(1)
  const [loading, setLoading] = useState<boolean>(false)
  const [refreshKey, setRefreshKey] = useState<number>(0)
  const [clusterStats, setClusterStats] = useState({
    totalCpu: 0,
    usedCpu: 0,
    healthyNodes: 0,
    totalNodes: 0,
    totalPods: 0,
  })

  useEffect(() => {
    const fetchNodes = async () => {
      try {
        const nodeList = await listNodes()
        setNodes(nodeList)

        // Calculate cluster stats
        const stats = {
          totalCpu: 0,
          usedCpu: 0,
          healthyNodes: 0,
          totalNodes: nodeList.length,
          totalPods: 0,
        }

        nodeList.forEach((node) => {
          stats.totalCpu += node.totalCpu
          stats.usedCpu += node.usedCpu
          if (node.status === "healthy") stats.healthyNodes++
          stats.totalPods += node.pods.length
        })

        setClusterStats(stats)
      } catch (error) {
        console.error("Failed to fetch nodes:", error)
      }
    }

    fetchNodes()

    // Set up polling for node updates
    const interval = setInterval(() => {
      fetchNodes()
    }, 5000)

    return () => clearInterval(interval)
  }, [refreshKey])

  const handleAddNode = async () => {
    setLoading(true)
    try {
      await createNode(cpuCores)
      setRefreshKey((prev) => prev + 1)
    } catch (error) {
      console.error("Failed to add node:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleLaunchPod = async () => {
    setLoading(true)
    try {
      await launchPod(podCpuReq)
      setRefreshKey((prev) => prev + 1)
    } catch (error) {
      console.error("Failed to launch pod:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "healthy":
        return (
          <Badge className="bg-green-500">
            <CheckCircle className="w-3 h-3 mr-1" /> Healthy
          </Badge>
        )
      case "unhealthy":
        return (
          <Badge className="bg-red-500">
            <AlertCircle className="w-3 h-3 mr-1" /> Unhealthy
          </Badge>
        )
      default:
        return (
          <Badge className="bg-yellow-500">
            <RefreshCw className="w-3 h-3 mr-1" /> Unknown
          </Badge>
        )
    }
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Kubernetes-like Cluster Simulator</h1>

      {/* Cluster Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Nodes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{clusterStats.totalNodes}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {clusterStats.healthyNodes} healthy / {clusterStats.totalNodes - clusterStats.healthyNodes} unhealthy
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Pods</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{clusterStats.totalPods}</div>
            <p className="text-xs text-muted-foreground mt-1">Across {clusterStats.totalNodes} nodes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">CPU Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {clusterStats.usedCpu} / {clusterStats.totalCpu}
            </div>
            <Progress value={(clusterStats.usedCpu / Math.max(clusterStats.totalCpu, 1)) * 100} className="h-2 mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Cluster Health</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Activity className="w-4 h-4 mr-2 text-green-500" />
              <span className="text-2xl font-bold">
                {clusterStats.totalNodes > 0
                  ? Math.round((clusterStats.healthyNodes / clusterStats.totalNodes) * 100)
                  : 0}
                %
              </span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">Overall cluster health</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="nodes">
        <TabsList className="mb-4">
          <TabsTrigger value="nodes">Nodes</TabsTrigger>
          <TabsTrigger value="pods">Pods</TabsTrigger>
        </TabsList>

        <TabsContent value="nodes">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Add Node</CardTitle>
                <CardDescription>Add a new node to the cluster</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">CPU Cores</label>
                    <Input
                      type="number"
                      min={1}
                      value={cpuCores}
                      onChange={(e) => setCpuCores(Number.parseInt(e.target.value))}
                      className="mt-1"
                    />
                  </div>
                  <Button onClick={handleAddNode} disabled={loading} className="w-full">
                    {loading ? "Adding..." : "Add Node"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Cluster Nodes</CardTitle>
                <CardDescription>List of all nodes in the cluster</CardDescription>
              </CardHeader>
              <CardContent>
                {nodes.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    No nodes available. Add a node to get started.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {nodes.map((node) => (
                      <div key={node.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center">
                              <Server className="w-5 h-5 mr-2" />
                              <h3 className="font-medium">Node {node.id.substring(0, 8)}</h3>
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              CPU: {node.usedCpu}/{node.totalCpu} cores
                            </div>
                            <div className="mt-2">
                              <Progress value={(node.usedCpu / node.totalCpu) * 100} className="h-2" />
                            </div>
                          </div>
                          <div>{getStatusBadge(node.status)}</div>
                        </div>

                        <div className="mt-4">
                          <h4 className="text-sm font-medium mb-2">Pods ({node.pods.length})</h4>
                          <div className="flex flex-wrap gap-2">
                            {node.pods.map((pod) => (
                              <Badge key={pod.id} variant="outline" className="flex items-center">
                                <Box className="w-3 h-3 mr-1" />
                                Pod {pod.id} ({pod.cpuRequest} CPU)
                              </Badge>
                            ))}
                            {node.pods.length === 0 && <span className="text-xs text-muted-foreground">No pods</span>}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="pods">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Launch Pod</CardTitle>
                <CardDescription>Create a new pod with CPU requirements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">CPU Request (cores)</label>
                    <Input
                      type="number"
                      min={1}
                      value={podCpuReq}
                      onChange={(e) => setPodCpuReq(Number.parseInt(e.target.value))}
                      className="mt-1"
                    />
                  </div>
                  <Button onClick={handleLaunchPod} disabled={loading} className="w-full">
                    {loading ? "Launching..." : "Launch Pod"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>All Pods</CardTitle>
                <CardDescription>List of all pods in the cluster</CardDescription>
              </CardHeader>
              <CardContent>
                {nodes.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">No nodes available. Add a node first.</div>
                ) : (
                  <div className="space-y-4">
                    {nodes.flatMap((node) => node.pods.map((pod) => ({ ...pod, nodeId: node.id }))).length === 0 ? (
                      <div className="text-center py-6 text-muted-foreground">
                        No pods available. Launch a pod to get started.
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {nodes.flatMap((node) =>
                          node.pods.map((pod) => (
                            <div key={`${node.id}-${pod.id}`} className="border rounded-lg p-4">
                              <div className="flex justify-between items-start">
                                <div>
                                  <div className="flex items-center">
                                    <Box className="w-5 h-5 mr-2" />
                                    <h3 className="font-medium">Pod {pod.id}</h3>
                                  </div>
                                  <div className="text-sm text-muted-foreground mt-1">CPU: {pod.cpuRequest} cores</div>
                                </div>
                                <Badge variant="outline">Node {node.id.substring(0, 8)}</Badge>
                              </div>
                            </div>
                          )),
                        )}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
