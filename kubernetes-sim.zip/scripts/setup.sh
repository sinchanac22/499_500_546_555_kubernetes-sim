#!/bin/bash

# Setup script for Kubernetes-like Cluster Simulation Framework

echo "Setting up Kubernetes-like Cluster Simulation Framework..."

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "Docker is not installed. Please install Docker first."
    exit 1
fi

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
npm install

# Build Docker images
echo "Building Docker images..."
docker build -t k8s-sim-node -f Dockerfile .
docker build -t k8s-sim-server -f Dockerfile.server .

# Create Docker network if it doesn't exist
if ! docker network inspect k8s-sim-network &> /dev/null; then
    echo "Creating Docker network..."
    docker network create k8s-sim-network
fi

echo "Setup complete!"
echo "To start the API server: npm run start:server"
echo "To start the web interface: npm run dev"
