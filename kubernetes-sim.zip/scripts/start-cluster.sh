#!/bin/bash

# Start script for Kubernetes-like Cluster Simulation Framework

echo "Starting Kubernetes-like Cluster Simulation Framework..."

# Start API server
echo "Starting API server..."
docker run -d --name k8s-sim-api-server \
  -p 3001:3001 \
  -v /var/run/docker.sock:/var/run/docker.sock \
  --network k8s-sim-network \
  k8s-sim-server

# Wait for API server to start
echo "Waiting for API server to start..."
sleep 5

echo "Cluster API server is running!"
echo "Web interface can be started with: npm run dev"
echo "Access the dashboard at: http://localhost:3000"
