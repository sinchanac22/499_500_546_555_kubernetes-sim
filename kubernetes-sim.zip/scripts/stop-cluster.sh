#!/bin/bash

# Stop script for Kubernetes-like Cluster Simulation Framework

echo "Stopping Kubernetes-like Cluster Simulation Framework..."

# Stop and remove API server container
if docker ps -a | grep -q k8s-sim-api-server; then
    echo "Stopping API server..."
    docker stop k8s-sim-api-server
    docker rm k8s-sim-api-server
fi

# Stop and remove all node containers
echo "Stopping node containers..."
docker ps -a | grep k8s-sim-node | awk '{print $1}' | xargs -r docker stop
docker ps -a | grep k8s-sim-node | awk '{print $1}' | xargs -r docker rm

echo "Cluster stopped successfully!"
